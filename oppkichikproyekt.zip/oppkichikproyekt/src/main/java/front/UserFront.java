package front;

import model.User;
import service.UserService;

import java.util.Scanner;


public class UserFront {
    private static Scanner scanner = new Scanner(System.in);
    public static void signUpUserIn(Scanner in , UserService userService){
        in = new Scanner(System.in);
        User user = new User();
        System.out.print("enter fullName: ");
        user.setName(in.nextLine());
        System.out.print("enter username: ");
        user.setUsername(in.nextLine());
        System.out.print("enter password: ");
        user.setPassword(in.nextLine());
        System.out.print("enter email: ");
        user.setEmail(in.nextLine());
        userService.signUp(user);
    }
    public static User signInUserIn(UserService userService){
        System.out.println("enter username :");
        String username = scanner.nextLine();
        System.out.println("enter password :");
        String password = scanner.nextLine();
        User user = userService.signIn(username,password);
        return user;
    }

}
