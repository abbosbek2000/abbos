package front;

import model.User;
import service.CardService;
import service.UserService;

import java.util.Scanner;
import java.util.UUID;

public class Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        UserService userService = new UserService(100);
        int step = 1;
        while (step != 0){
            System.out.println(
                    "0-> EXIT; 1-> SIGN UP , 2-> SIGN IN, 3-> LOG OUT");
            step = in.nextInt();
            switch (step){
                case 1:
                    UserFront.signUpUserIn( in,userService);
                    break;
                case 2:
                    User user = UserFront.signInUserIn(userService);
                    if (user != null)
                        Main.complete(user);
                    else
                        System.out.println("user not found");
                    break;
                default: userService.userList();

                    break;

            }
        }
    }
    public static void  complete(User user){
        Scanner in = new Scanner(System.in);
        System.out.println("nechta karta qo'shasan :");
        int cardMaxValue = in.nextInt();
        CardService cardService = new CardService(cardMaxValue);
        user.userCardsMaxValue(cardMaxValue);
        int step = 1;
        while (step != 0){
            System.out.println(
                    "1-> ADD CARD, 2-> EDIT CARD,\" +\n" +
                            "        \"3-> DELETE CARD");
            step = in.nextInt();
            switch (step){
                case 1:
                    UUID cardId = CardFront.addCardIn(cardService);
                    user.setUserCards(cardId);
                    break;
                case 2:

                break;
            }
        }


    }
}
