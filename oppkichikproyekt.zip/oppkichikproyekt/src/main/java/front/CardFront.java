package front;

import model.Card;
import model.User;
import service.CardService;
import service.UserService;
import java.util.Scanner;
import java.util.UUID;

public class CardFront {
    private static Scanner scanner = new Scanner(System.in);

    public static UUID addCardIn(CardService cardService){
        Card card = new Card();
        System.out.print("enter card name: ");
        card.setName(scanner.nextLine());
        System.out.print("enter card owner name: ");
        card.setOwnerName(scanner.nextLine());
        System.out.println("enter card number :");
        card.setCardNumber(scanner.nextLine());
        System.out.println("card expiry date :");
        card.setExpiryDate(scanner.nextLine());
        return cardService.addCard(card);
    }
}
