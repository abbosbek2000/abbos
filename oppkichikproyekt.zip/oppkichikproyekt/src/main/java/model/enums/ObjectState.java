package model.enums;

public enum ObjectState {
    EXIT(1),
    SIGN_UP(2),
    SIGN_IN(3),
    ADD_CARD(4),
    EDIT_CARD(5),
    DELETE_CARD(6);

    private int state;

    ObjectState(int state) {
        this.state = state;
    }

    public int getState() {
        return state;
    }
}
