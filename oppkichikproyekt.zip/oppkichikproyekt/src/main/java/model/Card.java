package model;

import model.base.BaseModel;
public class Card extends BaseModel {

    private String cardNumber;
    private String ownerName;
    private String expiryDate;
    private Double balance;

    public Card(String cardNumber, String ownerName, String expiryDate, Double balance) {
        this.cardNumber = cardNumber;
        this.ownerName = ownerName;
        this.expiryDate = expiryDate;
        this.balance = balance;
    }

    public Card() {

    }

    public String getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }

    public String getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(String expiryDate) {
        this.expiryDate = expiryDate;
    }

    public Double getBalance() {
        return balance;
    }

    public void setBalance(Double balance) {
        this.balance = balance;
    }
}
