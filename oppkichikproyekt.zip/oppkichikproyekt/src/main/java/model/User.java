package model;

import model.base.BaseModel;

import java.util.UUID;

public class User extends BaseModel {

    private String username; // phoneNumber
    private String password;
    private String email;
    private UUID cards[];

    public User(String username, String email) {
        this.username = username;
        this.email = email;
    }

    public User() {
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void userCardsMaxValue(Integer max){
        this.cards = new UUID[max];
    }

    public void setUserCards(UUID cardId){
        boolean isAddedCardId = false;
        for (int i = 0; i < cards.length; i++) {
            if (cards[i] == null) {
                cards[i] = cardId;
                isAddedCardId = true;
            }
            if (isAddedCardId)
                i = cards.length;
        }
    }

}
