package service;
import model.Card;

import java.util.UUID;

public class CardService {
    private Card[] cards;
    private Integer index = 0;

    public CardService(Integer max) {
        this.cards = new Card[max];
    }

    public UUID addCard(Card newCard){
        boolean isHasCard = false;
        for (Card card :this.cards) {
         if (card != null){
             if (card.getId().equals(newCard.getId())){
                 isHasCard = true;
             }
         }
         if (!isHasCard){
             this.cards[index++] = newCard;
             System.out.println("card added successfully :");
         }else
             System.out.println("card not found :");
        }
        return !isHasCard ? newCard.getId() : null;
    }
}
