package service;

import model.User;

import java.util.UUID;

public class UserService {

    private User[] users;
    private Integer index = 0;
    public UserService(int maxUser) {
        this.users = new User[maxUser];
    }

    public void signUp(User newUser) {
        boolean isHasUser = false;
        for (User user : this.users) {
            if (user != null){
                if (user.getUsername().equals(newUser.getUsername()))
                    isHasUser = true;
            }
        }
        if (!isHasUser) {
            this.users[ index++] = newUser;
            System.out.println("user successfully added");
        }else {
            System.out.println("this username already has");
        }
    }

    public User signIn(String username, String password){
        User signedUser = new User();
        signedUser = null;
        for (User user : this.users) {
            if (user != null) {
                if (user.getUsername().equals(username) && user.getPassword().equals(password))
                    signedUser = user;
            }
        }
        return signedUser;
    }

    protected void editUser(User editUser) {
        for (User user : this.users) {
            if (user.getId().equals(editUser.getId()))
                user = editUser;
        }
    }


    protected void deleteUser(UUID id) {
        for (User user : this.users) {
            if (user.getId().equals(id))
                user = null;
        }
    }
    public void userList() {
        for (User user : this.users) {
            if (user != null) {
                System.out.println(" -----------------------------");
                System.out.println("user id: " + user.getId());
                System.out.println("user name: " + user.getName());
                System.out.println("user username: " + user.getUsername());
                System.out.println("user email: " + user.getEmail());
                System.out.println(" -----------------------------");
            }
        }
    }
}
